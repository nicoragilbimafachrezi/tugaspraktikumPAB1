import 'package:flutter/material.dart';

class GridItem extends StatelessWidget {
  final IconData icon;
  final String label;

  GridItem({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Card(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.play_arrow), // Menampilkan ikon "Play Movie"
            SizedBox(height: 2),
            Text(label),
          ],
        ),
      ),
    );
  }
}