import 'package:flutter/material.dart';
import 'package:flutter/page2.dart';

class SecondPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Second Page'),
        backgroundColor: const Color.fromARGB(255, 63, 21, 19), // Mengubah warna latar belakang AppBar menjadi merah
      ),
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/spide 1.jpg'),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(50),
              ),
              width: 100,
              height: 100,
            ),
            SizedBox(height: 10),
            Text(
              'KUMPULAN FILM DORAEMON',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PlayPage(movieTitle: 'Film Doraemon')),
                );
              },
              child: Text('Play'),
            ),
          ],
        ),
      ),
    );
  }
}